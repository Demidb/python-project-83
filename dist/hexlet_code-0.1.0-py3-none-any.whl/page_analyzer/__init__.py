__all__ = ['app']

from page_analyzer.app import app