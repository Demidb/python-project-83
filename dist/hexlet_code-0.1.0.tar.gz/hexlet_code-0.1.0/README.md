### Hexlet tests and linter status:
[![Actions Status](https://github.com/Demidb/python-project-83/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-83/actions)

### Github Actions
[![hexlet-check](https://github.com/Demidb/python-project-83/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-83/actions/workflows/hexlet-check.yml)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/fca6b4618e70a644cdb8/maintainability)](https://codeclimate.com/github/Demidb/python-project-83/maintainability)

### Test Coverage Badge
<a href="https://codeclimate.com/github/Demidb/python-project-83/test_coverage"><img src="https://api.codeclimate.com/v1/badges/fca6b4618e70a644cdb8/test_coverage" /></a>



###Render
https://dashboard.render.com/static/srv-cqfr7opu0jms73871a3g/deploys/dep-cqfr7p1u0jms73871a8g
https://dashboard.render.com/web/srv-cqgb7s5ds78s73cbpvs0/deploys/dep-cqgbaft6l47c73bs7ldg?r=2024-07-24%4008%3A02%3A12%7E2024-07-24%4008%3A05%3A26